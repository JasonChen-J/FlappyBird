import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.animation.Timeline;
import javafx.animation.KeyFrame;
import java.util.ArrayList;
import javafx.util.Duration;
import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import javafx.application.*;
import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.canvas.*;
import javafx.scene.control.*;
import javafx.scene.control.Alert.*;
import javafx.scene.effect.*;
import javafx.scene.image.*;
import javafx.scene.input.*;
import javafx.scene.layout.*;
import javafx.scene.paint.*;
import javafx.scene.shape.*;
import javafx.scene.text.*;
import javafx.beans.value.*;
import javafx.event.*;
import javafx.animation.*;
import javafx.geometry.*;

import java.awt.image.BufferedImage;
import java.io.*;
import java.util.*;

import javax.imageio.ImageIO;
import javafx.embed.swing.SwingFXUtils;

import java.util.ArrayList;

/*Shuyang Chen
 * 
 * 
 * 
 */
public class flappy extends Application
{
    public static void main(String[] args)
    {
        try
        {
            launch(args);
        }
        catch (Exception error)
        {
            error.printStackTrace();
        }
        finally
        {
            System.exit(0);
        }
    }


    //create score
    //create condition
    int score;
    boolean condition = false;
    int ii = 1;
    int iii = 1;
    
    public void start(Stage mainStage)
    {
        mainStage.setTitle("Flappy Bird");

        //set up scene
        BorderPane root = new BorderPane();
        Scene mainScene = new Scene(root);
        mainStage.setScene(mainScene);
        
        //create menus
        Menu file = new Menu("File");
        MenuItem help = new MenuItem("Help");
        file.getItems().addAll(help );
        MenuBar bar = new MenuBar();
        bar.getMenus().addAll(file);


        root.setTop(bar);

        Canvas canvas = new Canvas(800,600);
        GraphicsContext context = canvas.getGraphicsContext2D();
        root.setCenter(canvas);

        // handle continuous inputs (as long as key is pressed)
        ArrayList<String> keyPressedList = new ArrayList<String>();
        // handle discrete inputs (once per key press)
        ArrayList<String> keyJustPressedList = new ArrayList<String>();

        mainScene.setOnKeyPressed(
                (KeyEvent event) ->
                {
                    String keyName = event.getCode().toString();
                    // avoid adding duplicates to lists
                    if ( !keyPressedList.contains(keyName) )
                    {
                        keyPressedList.add(keyName);
                        keyJustPressedList.add(keyName);
                    }
                }
        );

        mainScene.setOnKeyReleased(
                (KeyEvent event) ->
                {
                    String keyName = event.getCode().toString();
                    if ( keyPressedList.contains(keyName) )
                        keyPressedList.remove(keyName);
                }
        );

        ArrayList<Sprite> backList = new ArrayList<Sprite>();
        ArrayList<Sprite> birdList = new ArrayList<Sprite>();

        //background
        Sprite back = new Sprite("images/back.png");
        double x = 800;
        double y = 300;
        back.position.set(x,y);
        double angle = 180;
        back.velocity.setLength(-30);
        back.velocity.setAngle(angle);
        backList.add(back);
        
        //background
        Sprite back2 = new Sprite("images/back2.png");
        double xx = -2; // 300-800
        double yy = 300; // 100-500
        back2.position.set(xx,yy);
        double anglee = 180;
        back2.velocity.setLength(-30);
        back2.velocity.setAngle(anglee);
        backList.add(back2);
        
        ArrayList<Sprite> tubeList = new ArrayList<Sprite>();
        ArrayList<Sprite> tubeList3 = new ArrayList<Sprite>();

        //create bird
        Sprite bird = new Sprite("images/bird.png");
        bird.position.set(150,300);
        birdList.add(bird);
        
        //create game over
        Sprite lose = new Sprite("images/game-over.png");
        ArrayList<Sprite> loseList = new ArrayList<Sprite>();
        lose.position.set(400,300);
        loseList.add(lose);      

        AnimationTimer gameloop = new AnimationTimer()
        {
            public void handle(long nanotime)
            {
                //create tubes
                Timeline timeline = new Timeline(
                new KeyFrame(Duration.seconds(4*ii), e -> {
                Sprite tube2 = new Sprite("images/tube.png");

                
                double ttx = 850;
                double tty = 400+ 400 * Math.random();
                
                tube2.position.set(ttx,tty);
                double ttangle = 180;
                tube2.velocity.setLength(-30);
                tube2.velocity.setAngle(angle);
                tubeList.add(tube2); 
                })
                );
                ii++;
                timeline.play();
                
                //-----------------------
                //create tubes
                Timeline timeline2 = new Timeline(
                new KeyFrame(Duration.seconds(4*iii), e -> {
                Sprite tube3 = new Sprite("images/tube2.png");

                double tttx = 985;
                double ttty = 200 * Math.random();
                
                tube3.position.set(tttx,ttty);
                double tttangle = 180;
                tube3.velocity.setLength(-30);
                tube3.velocity.setAngle(angle);
                tubeList3.add(tube3); 
                // code to execute here...
                })
                );
                
                iii++;
                timeline2.play();
                //----------------------
                if ( keyPressedList.contains("SPACE") )
                {
                    bird.velocity.setLength(150);
                    bird.velocity.setAngle( -90 );
                }
                else // not pressing up
                {
                    bird.velocity.setLength(100);
                    bird.velocity.setAngle( 90 );
                }

                for (int tubeNum = 0; tubeNum < tubeList.size(); tubeNum++)
                {
                    Sprite tube = tubeList.get(tubeNum);
                    if ((bird.position.x>tube.position.x-48)&&(bird.position.y>tube.position.y-210)&&(bird.position.x<tube.position.x+59))
                    {
                            tubeList.remove(tubeNum);
                            birdList.remove(bird);
                            condition = true;
                    }
                    if(bird.position.x>tube.position.x-48&& bird.position.y<tube.position.y-210)
                    {
                        if(!condition)
                        score += 10;
                    }
                }
                
                for (int tubeNum = 0; tubeNum < tubeList3.size(); tubeNum++)
                {
                    Sprite tube3 = tubeList3.get(tubeNum);
                    if(!condition)
                    {
                    if ((bird.position.x>tube3.position.x-48)&&(bird.position.y<tube3.position.y+210)&&(bird.position.x<tube3.position.x+59))
                    {
                            tubeList3.remove(tubeNum);
                            birdList.remove(bird);
                            condition = true;
                    }
                    }
                    if(bird.position.x>tube3.position.x-50&& bird.position.y<tube3.position.y-210)
                    {
                        if(!condition)
                        score += 10;
                    }
                }
                
                // after processing user input, clear justPressedList
                keyJustPressedList.clear();

                for (Sprite back : backList)
                    back.update(1/60.0);

                for (Sprite back : backList)
                    back.render(context);
                                       
                for (Sprite bird : birdList)
                { bird.update(1/60.0);
                    bird.render(context);
                }
                
                for (Sprite tube : tubeList)
                { tube.update(1/60.0);
                    tube.render(context);
                }
                
                for (Sprite tube3 : tubeList3)
                { tube3.update(1/60.0);
                    tube3.render(context);
                }
                             
               for (Sprite bird : birdList)
                {
                        if(bird.position.y<0)
                        {
                            birdList.remove(bird);
                            condition = true;
                        }
                }
                
                for (Sprite tube : tubeList)
                {
                        if(tube.position.x<-100)
                        {
                            tubeList.remove(tube);
                        }
                }
                
                for (Sprite tube3 : tubeList3)
                {
                        if(tube3.position.x<-150)
                        {
                            tubeList3.remove(tube3);
                        }
                }
                
                if(condition)
                {
                lose.render(context);
                }
                // draw score on screen
                context.setFill(Color.WHITE);
                context.setStroke(Color.GREEN);
                context.setFont( new Font("Arial Black", 36) );
                context.setLineWidth(3);
                String text = "Score: " + score;
                int textX = 500;
                int textY = 50;
                context.fillText(text, textX, textY);
                context.strokeText(text, textX, textY);
            }
        };

        help.setOnAction(
               (ActionEvent event) ->
               {
                Alert infoAlert = new Alert( AlertType.INFORMATION );
                infoAlert.setTitle("Help");
                infoAlert.setHeaderText("Instruction");
                infoAlert.setContentText("Space to jump");              
                infoAlert.showAndWait();
               }
        );
        
        gameloop.start();

        mainStage.show();
    }
}
